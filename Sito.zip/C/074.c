#include <stdio.h>
#include <stdlib.h>
int main(){
    char buffer[100];
    FILE *fp;
    int i;
    int n;
    fp=fopen("input.txt", "r");
    if( fp == NULL )
        printf("Errore : il file non esiste\n");
    while((n=fread(buffer, 1, 100, fp))!=0){
        buffer[n]='\0';
        printf("%s", buffer); 
    }
    fclose(fp);
    return 0;
}
